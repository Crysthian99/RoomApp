// ignore_for_file: use_build_context_synchronously

import 'package:encrypt_password_manager/services/auth_services.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:one_context/one_context.dart';

import '../router/app_router.dart';

// THis class help us to navigate to screen when user login or logout

class SplashServices {
  static String userId = "";

  static initialize() async {
    await Future.delayed(const Duration(seconds: 3));
    AuthServices().authState.listen(naviagte);
  }

  static naviagte(User? user) async {
    if (user == null) {
      userId = "";
      OneContext().pushNamedAndRemoveUntil(AppRoutes.LOGIN, (route) => false);
    } else {
      userId = user.uid;

      OneContext().pushNamedAndRemoveUntil(AppRoutes.HOME, (route) => false);
    }
  }
}
