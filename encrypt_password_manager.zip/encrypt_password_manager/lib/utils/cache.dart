import 'package:shared_preferences/shared_preferences.dart';

class SharedPrefs {
  static late final SharedPreferences myPrefs;

  static Future<SharedPreferences> init() async => myPrefs = await SharedPreferences.getInstance();

  static bool getBool(String key) => myPrefs.getBool(key) ?? false;
  static int getInt(String key) => myPrefs.getInt(key) ?? 0;
  static String getString(String key) => myPrefs.getString(key) ?? "";

  static Future<bool> setBool(String key, bool value) => myPrefs.setBool(key, value);
  static Future<bool> setInt(String key, int value) => myPrefs.setInt(key, value);
  static Future<bool> setString(String key, String value) => myPrefs.setString(key, value);

  static Future<bool> removeValue(String key) => myPrefs.remove(key);
  static Future<bool> removeAll() => myPrefs.clear();
}
