import 'dart:convert';
import 'dart:math';

import 'package:aes256gcm/aes256gcm.dart';
import 'package:encrypt_password_manager/utils/cache.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:one_context/one_context.dart';
import 'package:password_generator/password_generator.dart';

class Helper {
  static final Random _random = Random.secure();

// generate master key

  static String createSecurePassword([int length = 32]) {
    var values = List<int>.generate(length, (i) => _random.nextInt(256));
    return base64Url.encode(values);
  }

// encrypt password

  static Future<String> securePassword(String myPassword) async {
    String secureKey = SharedPrefs.getString("masterkey");

    final encrypted = await Aes256Gcm.encrypt(myPassword, secureKey);

    return encrypted;
  }

  // unencrypt password

  static Future<String> unSecurePassword(String encryptedPassword) async {
    String secureKey = SharedPrefs.getString("masterkey");
    final encrypted = await Aes256Gcm.decrypt(encryptedPassword, secureKey);

    return encrypted;
  }

  // generate strong password setting

  static final _passwordGenerator = PasswordGenerator(
    length: 15,
    hasCapitalLetters: true,
    hasNumbers: true,
    hasSmallLetters: true,
    hasSymbols: true,
  );

  // generate strong password in menu button

  static void generateStrongPassword() {
    String password = _passwordGenerator.generatePassword();
    OneContext().pop();

    OneContext().showDialog(
      builder: (p0) {
        return AlertDialog(
          title: SelectableText(
            password,
            style: TextStyle(fontSize: 18.sp),
          ),
        );
      },
    );
  }

  // generate strong password in edit and add accounts page

  static String generateStrongPasswordAndReturn() {
    return _passwordGenerator.generatePassword();
  }
}
