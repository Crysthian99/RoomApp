import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../theme/colors.dart';

class Loading extends StatelessWidget {
  final double? value;
  const Loading({Key? key, this.value}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Center(
      child: SizedBox(
        width: 38.w,
        height: 38.h,
        child: CircularProgressIndicator(
          value: value,
          strokeWidth: 5.0.sp,
          valueColor: const AlwaysStoppedAnimation<Color>(primaryColor),
        ),
      ),
    );
  }
}
