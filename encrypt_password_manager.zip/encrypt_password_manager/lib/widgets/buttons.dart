import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../theme/colors.dart';

class CustomButton extends StatelessWidget {
  final VoidCallback? onPressed;
  final String text;
  final Color color;
  final Color textColor;
  final double? width;
  final bool? fullWidth;

  const CustomButton({
    Key? key,
    required this.onPressed,
    required this.text,
    this.color = primaryColor,
    this.textColor = Colors.white,
    this.width,
    this.fullWidth = false,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Center(
      child: SizedBox(
        width: fullWidth == true ? double.infinity : width,
        height: 45.h,
        child: ElevatedButton(
          style: ElevatedButton.styleFrom(
            foregroundColor: textColor,
            backgroundColor: color,
            elevation: 0,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(100.0),
            ),
          ),
          onPressed: onPressed,
          child: Text(
            text,
            style: TextStyle(fontSize: 14.sp),
          ),
        ),
      ),
    );
  }
}

class CustomOutlinedButton extends StatelessWidget {
  final void Function()? onPressed;
  final String text;
  final bool? fullWidth;
  const CustomOutlinedButton({super.key, required this.onPressed, required this.text, this.fullWidth});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 45.h,
      width: fullWidth == null ? null : MediaQuery.of(context).size.width,
      child: OutlinedButton(
        onPressed: onPressed,
        style: OutlinedButton.styleFrom(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(100.0),
          ),
          side: BorderSide(color: primaryColor, width: 0.5.w),
        ),
        child: Text(
          text,
          style: TextStyle(fontSize: 14.sp),
        ),
      ),
    );
  }
}
