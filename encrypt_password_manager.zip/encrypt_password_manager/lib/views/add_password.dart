import 'package:encrypt_password_manager/providers/main_provider.dart';
import 'package:encrypt_password_manager/utils/helper.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';

import '../../widgets/input_decoration.dart';
import '../widgets/buttons.dart';

class AddPassword extends StatefulWidget {
  const AddPassword({super.key});

  @override
  State<AddPassword> createState() => _AddPasswordState();
}

class _AddPasswordState extends State<AddPassword> {
  final _formKey = GlobalKey<FormState>();
  final _urlController = TextEditingController();
  final _usernameController = TextEditingController();
  final _passwordController = TextEditingController();

  Widget _urlField() {
    return Padding(
      padding: const EdgeInsets.only(top: 15).r,
      child: TextFormField(
        controller: _urlController,
        keyboardType: TextInputType.text,
        decoration: inputDecoration(hintText: "url"),
        validator: (value) {
          if (value == null || value.isEmpty) {
            return "required";
          }
          return null;
        },
      ),
    );
  }

  Widget _userNameField() {
    return Padding(
      padding: const EdgeInsets.only(top: 15).r,
      child: TextFormField(
        controller: _usernameController,
        keyboardType: TextInputType.text,
        decoration: inputDecoration(hintText: "Username/Email"),
        validator: (value) {
          if (value == null || value.isEmpty) {
            return "required";
          }
          return null;
        },
      ),
    );
  }

  Widget _passwordField() {
    return Padding(
      padding: const EdgeInsets.only(top: 15).r,
      child: TextFormField(
        controller: _passwordController,
        keyboardType: TextInputType.visiblePassword,
        decoration: inputDecoration(hintText: "Password"),
        validator: (value) {
          if (value == null || value.isEmpty) {
            return "required";
          }
          return null;
        },
      ),
    );
  }

  Widget _generatePasswordButton() {
    return Padding(
      padding: const EdgeInsets.only(top: 15).r,
      child: CustomButton(
          onPressed: () {
            _passwordController.text = Helper.generateStrongPasswordAndReturn();
            setState(() {});
          },
          text: "Generate Password"),
    );
  }

  Widget _addButton() => Padding(
      padding: const EdgeInsets.only(top: 20).r,
      child: Consumer<MainProvider>(builder: (context, provider, __) {
        return CustomButton(
          fullWidth: true,
          onPressed: provider.isLoading
              ? null
              : () async {
                  if (_formKey.currentState!.validate()) {
                    provider.addPassword(
                      _urlController.text.trim(),
                      _usernameController.text.trim(),
                      _passwordController.text,
                    );
                  }
                },
          text: "Add",
        );
      }));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Add new password"),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16).r,
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _urlField(),
              _userNameField(),
              _passwordField(),
              _generatePasswordButton(),
              _addButton(),
            ],
          ),
        ),
      ),
    );
  }
}
