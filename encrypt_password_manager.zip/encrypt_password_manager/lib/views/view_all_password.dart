import 'package:encrypt_password_manager/providers/main_provider.dart';
import 'package:encrypt_password_manager/router/app_router.dart';
import 'package:encrypt_password_manager/theme/colors.dart';
import 'package:encrypt_password_manager/utils/helper.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:one_context/one_context.dart';
import 'package:provider/provider.dart';

class ViewAllPassword extends StatefulWidget {
  const ViewAllPassword({super.key});

  @override
  State<ViewAllPassword> createState() => _ViewAllPasswordState();
}

class _ViewAllPasswordState extends State<ViewAllPassword> {
  @override
  void initState() {
    super.initState();
    Future.microtask(() => context.read<MainProvider>().viewAllPassword());
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<MainProvider>(builder: (context, provider, __) {
      return Column(
        children: [
          ListTile(
            title: Text(
              "Saved accounts",
              style: TextStyle(fontSize: 18.sp, fontWeight: FontWeight.bold),
            ),
            trailing: provider.allPasswordsList.isEmpty
                ? const SizedBox()
                : Text(
                    provider.allPasswordsList.length.toString(),
                    style: TextStyle(fontSize: 18.sp, fontWeight: FontWeight.bold),
                  ),
          ),
          provider.allPasswordsList.isEmpty
              ? const Center(
                  child: Text("You dont have any save accounts"),
                )
              : ListView.separated(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: provider.allPasswordsList.length,
                  separatorBuilder: (context, index) {
                    return const Divider(color: kBorder);
                  },
                  itemBuilder: (BuildContext context, int index) {
                    final data = provider.allPasswordsList[index];
                    return Slidable(
                      // Specify a key if the Slidable is dismissible.
                      key: const ValueKey(0),

                      endActionPane: ActionPane(
                        extentRatio: 0.3,
                        motion: const ScrollMotion(),
                        children: [
                          SlidableAction(
                            onPressed: (_) {
                              provider.deletePassword(data.id);
                            },
                            backgroundColor: const Color(0xFFFE4A49),
                            foregroundColor: Colors.white,
                            icon: Icons.delete,
                          ),
                        ],
                      ),
                      child: ListTile(
                        title: Text(data["url"]),
                        subtitle: Text(data["username"]),
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            IconButton(
                              onPressed: () async {
                                final password = await Helper.unSecurePassword(data["password"]);
                                OneContext().pushNamed(AppRoutes.EDITPASSWORD, arguments: {
                                  "docid": data.id,
                                  "url": data["url"],
                                  "username": data["username"],
                                  "password": password,
                                });
                              },
                              icon: Image.asset(
                                "assets/edit.png",
                                height: 20.h,
                                width: 20.h,
                              ),
                            ),
                            IconButton(
                              onPressed: () {
                                provider.showPassword(data["password"]);
                              },
                              icon: Image.asset(
                                "assets/showpassword.png",
                                height: 20.h,
                                width: 20.h,
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
        ],
      );
    });
  }
}
