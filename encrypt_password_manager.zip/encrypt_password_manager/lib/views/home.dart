import 'package:encrypt_password_manager/providers/auth_provider.dart';
import 'package:encrypt_password_manager/providers/main_provider.dart';
import 'package:encrypt_password_manager/router/app_router.dart';
import 'package:encrypt_password_manager/theme/colors.dart';
import 'package:encrypt_password_manager/utils/helper.dart';
import 'package:encrypt_password_manager/views/view_all_password.dart';
import 'package:encrypt_password_manager/widgets/loading.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:one_context/one_context.dart';
import 'package:provider/provider.dart';

import 'lock.dart';

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  @override
  void initState() {
    super.initState();

    Future.microtask(() => context.read<MainProvider>().init());
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<MainProvider>(builder: (context, provider, __) {
      return Scaffold(
        drawer: Drawer(
          child: Column(
            children: [
              DrawerHeader(
                decoration: const BoxDecoration(color: primaryColor),
                child: SizedBox(
                  width: 1.sw,
                  child: Center(
                    child: Text(
                      "Password Manager Licenta",
                      style: TextStyle(fontSize: 24.sp, color: Colors.white, fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
              ),
              ListTile(
                title: Text(
                  "Generate Strong password",
                  style: TextStyle(fontSize: 14.sp),
                ),
                trailing: const Icon(Icons.arrow_forward),
                onTap: () {
                  Helper.generateStrongPassword();
                },
              ),
            ],
          ),
        ),
        appBar: AppBar(
          title: const Text("Password Manager Licenta"),
          actions: provider.bioAuthenticate == false
              ? []
              : [
                  if (provider.isMasterKeyCreated)
                    IconButton(
                      onPressed: () {
                        provider.downloadKey();
                      },
                      icon: Image.asset("assets/key.png"),
                    ),
                  IconButton(
                    onPressed: () {
                      context.read<AuthProvider>().logout();
                    },
                    icon: Image.asset(
                      "assets/logout.png",
                      height: 20.h,
                      width: 20.h,
                    ),
                  ),
                ],
        ),
        body: provider.isLoading
            ? const Loading()
            : Stack(
                children: [
                  SingleChildScrollView(
                    padding: const EdgeInsets.all(16).r,
                    child: Column(
                      children: [
                        if (provider.isMasterKeyCreated == false)
                          ElevatedButton.icon(
                            style: ElevatedButton.styleFrom(backgroundColor: Colors.white),
                            icon: Image.asset(
                              "assets/key.png",
                              height: 40.h,
                              width: 40.h,
                            ),
                            onPressed: () async {
                              provider.generateAndSaveMasterKey();
                            },
                            label: const Text("Generate Master Key"),
                          ),
                        if (provider.isMasterKeyCreated == true) const ViewAllPassword()
                      ],
                    ),
                  ),
                  provider.bioAuthenticate == false ? const Lock() : const SizedBox(),
                ],
              ),
        floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
        floatingActionButton: provider.isMasterKeyCreated == false || provider.bioAuthenticate == false
            ? const SizedBox()
            : FloatingActionButton.large(
                backgroundColor: primaryColor,
                child: const Icon(Icons.add),
                onPressed: () {
                  OneContext().pushNamed(AppRoutes.ADDPASSWORD);
                },
              ),
      );
    });
  }
}
