import 'package:encrypt_password_manager/providers/auth_provider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';

class Login extends StatelessWidget {
  const Login({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16).r,
          child: Column(
            children: [
              Text(
                "Password Manager\nLicenta",
                textAlign: TextAlign.center,
                style: TextStyle(fontWeight: FontWeight.w900, fontSize: 24.sp),
              ),
              SizedBox(height: 50.h),
              ElevatedButton.icon(
                style: ElevatedButton.styleFrom(backgroundColor: Colors.white),
                icon: Image.asset(
                  "assets/google.png",
                  height: 20.h,
                  width: 20.h,
                ),
                onPressed: () async {
                  context.read<AuthProvider>().sigInWithGoogle();
                },
                label: const Text("Google Sign In"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
