import 'package:flutter/material.dart';

const primaryColor = Color(0xFF4A148C);
const kBorder = Color(0xFFdadcdf);
const kgrey = Color(0xFF5f6367);
