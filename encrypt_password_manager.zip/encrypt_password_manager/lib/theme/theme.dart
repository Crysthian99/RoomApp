import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import 'colors.dart';

ThemeData appTheme = ThemeData(
  useMaterial3: true,
  brightness: Brightness.light,
  scaffoldBackgroundColor: Colors.white,
  splashFactory: InkRipple.splashFactory,
  dialogBackgroundColor: Colors.white,
  cardTheme: const CardTheme(color: Colors.white, surfaceTintColor: Colors.white),
  appBarTheme:
      AppBarTheme(surfaceTintColor: Colors.transparent, titleTextStyle: TextStyle(fontSize: 18.sp, color: Colors.black, fontWeight: FontWeight.w500)),
  drawerTheme: const DrawerThemeData(backgroundColor: Colors.white, surfaceTintColor: Colors.white),
  dialogTheme: const DialogTheme(backgroundColor: Colors.white, surfaceTintColor: Colors.white),
  // input decoration
  inputDecorationTheme: InputDecorationTheme(
    border: OutlineInputBorder(
      borderRadius: BorderRadius.circular(5),
      borderSide: const BorderSide(color: kBorder, width: 0.5),
    ),
    enabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(5),
      borderSide: const BorderSide(color: kBorder, width: 0.5),
    ),
    focusedBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(5),
      borderSide: const BorderSide(color: primaryColor, width: 2),
    ),
    errorBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(5),
      borderSide: const BorderSide(color: Colors.red, width: 2),
    ),
    disabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(5),
      borderSide: const BorderSide(color: kBorder, width: 0.5),
    ),
    focusedErrorBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(5),
      borderSide: const BorderSide(color: primaryColor, width: 2),
    ),
    contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 12).r,
    // hintStyle: const TextStyle(
    //   color: kgrey,
    //   fontWeight: FontWeight.w500,
    //   fontSize: 13,
    // ),
    hintStyle: TextStyle(color: kgrey.withOpacity(0.6), fontSize: 13.sp),

    prefixIconColor: primaryColor,
    suffixIconColor: primaryColor,
  ),
  iconTheme: IconThemeData(size: 25.h),

  // cursor color
  cupertinoOverrideTheme: const CupertinoThemeData(
    primaryColor: primaryColor,
  ),
  textSelectionTheme: const TextSelectionThemeData(
    cursorColor: primaryColor,
  ),

  textTheme: TextTheme(
    bodyLarge: TextStyle(fontSize: 14.sp, color: Colors.black),
    bodyMedium: TextStyle(fontSize: 12.sp, color: Colors.black),
    bodySmall: TextStyle(fontSize: 10.sp, color: Colors.black),
    titleLarge: TextStyle(fontSize: 14.sp, color: Colors.black),
    titleMedium: TextStyle(fontSize: 12.sp, color: Colors.black),
    titleSmall: TextStyle(fontSize: 10.sp, color: Colors.black),
    displayLarge: TextStyle(fontSize: 14.sp, color: Colors.black),
    displayMedium: TextStyle(fontSize: 12.sp, color: Colors.black),
    displaySmall: TextStyle(fontSize: 10.sp, color: Colors.black),
    headlineLarge: TextStyle(fontSize: 14.sp, color: Colors.black),
    headlineMedium: TextStyle(fontSize: 12.sp, color: Colors.black),
    headlineSmall: TextStyle(fontSize: 10.sp, color: Colors.black),
    labelLarge: TextStyle(fontSize: 14.sp, color: Colors.black),
    labelMedium: TextStyle(fontSize: 12.sp, color: Colors.black),
    labelSmall: TextStyle(fontSize: 10.sp, color: Colors.black),
  ),

  colorScheme: ThemeData().colorScheme.copyWith(primary: primaryColor),
);
