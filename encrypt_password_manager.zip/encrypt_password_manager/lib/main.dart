import 'package:encrypt_password_manager/providers/auth_provider.dart';
import 'package:encrypt_password_manager/providers/main_provider.dart';
import 'package:encrypt_password_manager/router/app_router.dart';
import 'package:encrypt_password_manager/theme/theme.dart';
import 'package:encrypt_password_manager/utils/cache.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:one_context/one_context.dart';
import 'package:provider/provider.dart';

import 'firebase_options.dart';

Future main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Initialize the firebase

  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);

  // Initialize the cache

  await SharedPrefs.init();

  SystemChrome.setSystemUIOverlayStyle(
    SystemUiOverlayStyle.dark.copyWith(statusBarColor: Colors.transparent),
  );

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthProvider()),
        ChangeNotifierProvider(create: (_) => MainProvider()),
      ],
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
        designSize: const Size(360, 690),
        minTextAdapt: true,
        splitScreenMode: true,
        useInheritedMediaQuery: true,
        builder: (context, child) {
          return MaterialApp(
            builder: OneContext().builder,
            navigatorKey: OneContext().key,
            initialRoute: AppRoutes.SPLASH,
            routes: AppRoutes.getAppRoutes(),
            debugShowCheckedModeBanner: false,
            title: 'Password Manager Licenta',
            theme: appTheme,
          );
        });
  }
}
