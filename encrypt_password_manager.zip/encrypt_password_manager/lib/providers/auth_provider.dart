import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:encrypt_password_manager/utils/cache.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';
import 'package:google_sign_in/google_sign_in.dart';

import '../services/auth_services.dart';
import '../utils/alerts.dart';

class AuthProvider extends ChangeNotifier {
  // Users table in firebase
  CollectionReference collectionsUsers = FirebaseFirestore.instance.collection("users");
  bool isLoading = false;

  void loading(bool state) {
    isLoading = state;
    notifyListeners();
  }

// Sigin to google

  Future sigInWithGoogle() async {
    loading(true);
    try {
      final userCredential = await AuthServices().signInWithGoogle();

      User? user = userCredential.user;

      if (user != null) {
        // If user is new create data for this user in users table otherwise no need to create

        if (userCredential.additionalUserInfo!.isNewUser) {
          await saveUserDate(user.uid);
        }
      }

      loading(false);
    } catch (e) {
      debugPrint(e.toString());
      loading(false);
    }
  }

  // Users data to store in users table when new people join

  Future saveUserDate(String userId) async {
    try {
      await collectionsUsers.doc(userId).set(
        {
          "userid": userId,
          "master_key": false,
          "key_file": "",
        },
        SetOptions(merge: true),
      );
    } catch (e) {
      NotificationsService.showToast(e.toString());
    }
  }

  //Logout user

  Future<void> logout() async {
    await FirebaseAuth.instance.signOut();
    final googleSign = GoogleSignIn();
    await googleSign.signOut();
    await SharedPrefs.removeAll();
  }
}
