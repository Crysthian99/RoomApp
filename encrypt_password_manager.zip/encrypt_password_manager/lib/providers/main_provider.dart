import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:encrypt_password_manager/services/splash_services.dart';
import 'package:encrypt_password_manager/utils/alerts.dart';
import 'package:encrypt_password_manager/widgets/buttons.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:local_auth/local_auth.dart';
import 'package:one_context/one_context.dart';
import 'package:permission_handler/permission_handler.dart';

import '../utils/cache.dart';
import '../utils/helper.dart';

class MainProvider extends ChangeNotifier {
  // Fingerprint

  LocalAuthentication auth = LocalAuthentication();
  bool supportState = false;
  bool bioAuthenticate = false;

  // User table in firebae
  final col = FirebaseFirestore.instance.collection("users");

  // Current sigin user storage path for masterkey

  final storeagePath = FirebaseStorage.instance.ref(SplashServices.userId);

  bool isLoading = true;

  bool isMasterKeyCreated = false;
  String securePassword = "";
  String fileUrl = "";
  bool storage = true;

  List allPasswordsList = [];

  late StreamSubscription userDataStream;
  late StreamSubscription userPasswordStream;

  void loading(bool state) {
    isLoading = state;
    notifyListeners();
  }

  // Initialize this to fetch user data and ask for fingerprint everytime when user open app or sigin to app

  Future init() async {
    await fetchUserData();
    await authenticate();
  }

  Future fetchUserData() async {
    try {
      loading(true);

      userDataStream = col.doc(SplashServices.userId).snapshots().listen((event) {
        if (event.exists) {
          isMasterKeyCreated = event.get("master_key");
          if (isMasterKeyCreated == true) {
            fileUrl = event.get("key_file");
            getMasterKeyFromStorage(event.get("key_file"));
          }
        }

        notifyListeners();
        loading(false);
      });
    } catch (e) {
      loading(false);
    }
  }

  // Method for generate master key and save to device and also save to firebase storage
  Future generateAndSaveMasterKey() async {
    // Here we are getting getting generated masterkey from this method which is in helper class
    securePassword = Helper.createSecurePassword();

    try {
      // asking for permission
      bool permission = await checkPermission();
      if (permission == false) {
        return;
      }

      loading(true);
      //android download storage path
      const directory = "/storage/emulated/0/Download/";

      final File file = File('${directory}masterkey.txt');

      // save to device
      await file.writeAsString(securePassword, mode: FileMode.writeOnly);

      // save to firebase storage

      await saveToCloudStorage(file);
      NotificationsService.showToast("Master key downloaded");
    } catch (e) {
      loading(false);
      debugPrint(e.toString());
      NotificationsService.showToast("Unable to save file");
    }
  }

  Future saveToCloudStorage(File file) async {
    try {
      await storeagePath.putFile(File(file.path));
      await storeagePath.getDownloadURL().then((value) {
        updateMasterKeyFileUrl(value);
      });
    } catch (e) {
      debugPrint("Error saveToCloudStorage: $e");
    }
  }

  // when user generate master key after saving the master key in device and storage
  // we will upate the user data in users table like master_key to true (Means user created the master key)

  Future updateMasterKeyFileUrl(String url) async {
    try {
      col.doc(SplashServices.userId).update({
        "master_key": true,
        "key_file": url,
      });
    } catch (e) {
      debugPrint("Error updateMasterKeyFileUrl: $e");
    }
  }

  // When ever user login to the app we will fetch masterkey from firebase storage
  // and save in the device cache memory

  Future getMasterKeyFromStorage(String fileUrl) async {
    try {
      final path = FirebaseStorage.instance.refFromURL(fileUrl);
      Uint8List? downloadedData = await path.getData();
      String data = utf8.decode(downloadedData ?? []);
      await saveKeyToCache(data);
    } catch (e) {
      debugPrint("Error updateMasterKeyFileUrl: $e");
    }
  }

  Future saveKeyToCache(String key) async {
    await SharedPrefs.setString("masterkey", key);
  }

  Future<bool> checkPermission() async {
    await Permission.manageExternalStorage.request();

    if (await Permission.manageExternalStorage.isGranted) {
      return true;
    } else if (await Permission.manageExternalStorage.isPermanentlyDenied) {
      openAppSettings();
    }

    return false;
  }

  // Add password in firebase in users => passwords =[]

  Future addPassword(String url, String username, String password) async {
    final encrypted = await Helper.securePassword(password);
    try {
      col.doc(SplashServices.userId).collection("passwords").add({
        "url": url,
        "username": username,
        "password": encrypted,
      });
      OneContext().pop();
      NotificationsService.showToast("Password added");
    } catch (e) {
      debugPrint(e.toString());
      loading(false);
    }
  }

  // view all password of users

  Future viewAllPassword() async {
    try {
      userPasswordStream = col.doc(SplashServices.userId).collection("passwords").snapshots().listen((event) {
        allPasswordsList = event.docs;
        notifyListeners();
        loading(false);
      });
    } catch (e) {
      debugPrint(e.toString());
      loading(false);
    }
  }

  // show password for selected account using EYE button

  Future showPassword(String password) async {
    // uncrypt method class in helper
    // you can check this class in UTILS folde
    final unEncrypted = await Helper.unSecurePassword(password);

    try {
      // Show password in dialog

      OneContext().showDialog(
        builder: (p0) {
          return AlertDialog(
            title: Text(
              "Password",
              style: TextStyle(fontSize: 13.sp, fontWeight: FontWeight.w500),
            ),
            content: SelectableText(
              unEncrypted,
              style: TextStyle(fontSize: 13.sp),
            ),
            actions: [
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  CustomButton(
                      onPressed: () {
                        OneContext().popDialog();
                      },
                      text: "Ok"),
                ],
              )
            ],
          );
        },
      );
    } catch (e) {
      debugPrint(e.toString());
    }
  }

  // Edit password or other details and update in database

  Future editPassword(String docid, String url, String username, String password) async {
    final encrypted = await Helper.securePassword(password);

    try {
      col.doc(SplashServices.userId).collection("passwords").doc(docid).update({
        "url": url,
        "username": username,
        "password": encrypted,
      });
      OneContext().pop();
      NotificationsService.showToast("Updated");
    } catch (e) {
      debugPrint(e.toString());
    }
  }

  // Download key whenever user want

  Future downloadKey() async {
    try {
      bool permission = await checkPermission();
      if (permission == false) {
        return;
      }

      var httpClient = HttpClient();

      const directory = "/storage/emulated/0/Download/";
      var request = await httpClient.getUrl(Uri.parse(fileUrl));

      var response = await request.close();
      var bytes = await consolidateHttpClientResponseBytes(response);

      final File file = File('${directory}masterkey.txt');

      await file.writeAsBytes(bytes, mode: FileMode.writeOnly);

      NotificationsService.showToast("key save to download directory");
    } catch (e) {
      debugPrint(e.toString());
    }
  }

  // Delete account in database

  Future deletePassword(String docid) async {
    try {
      col.doc(SplashServices.userId).collection("passwords").doc(docid).delete();
      NotificationsService.showToast("Password deleted");
    } catch (e) {
      debugPrint(e.toString());
    }
  }

  // Finger Print initialize

  void initBioMetric() {
    auth = LocalAuthentication();
    auth.isDeviceSupported().then((bool isSupported) {
      supportState = isSupported;
      notifyListeners();
    });
  }

  // Ask for fingerprint untill True

  Future<void> authenticate() async {
    try {
      bool authenticated = await auth.authenticate(
        localizedReason: 'Fingerprint required',
        options: const AuthenticationOptions(
          stickyAuth: true,
          biometricOnly: true,
        ),
      );

      debugPrint("Authenticated : $authenticated");

      bool isauth = authenticated;
      if (isauth) {
        bioAuthenticate = true;
      } else {
        authenticate();
      }
      notifyListeners();
    } catch (e) {
      debugPrint("Bio ${e.toString()}");
    }

    // we can call setState here
  }

  Future<void> getAvailableBiometrics() async {
    List<BiometricType> availableBiometrics = await auth.getAvailableBiometrics();

    debugPrint("List of availableBiometrics : $availableBiometrics");

    // than we can call setState
  }
}
