// ignore_for_file: constant_identifier_names
import 'package:encrypt_password_manager/views/add_password.dart';
import 'package:encrypt_password_manager/views/edit_password.dart';
import 'package:encrypt_password_manager/views/home.dart';
import 'package:encrypt_password_manager/views/view_all_password.dart';
import 'package:flutter/material.dart';

import '../views/auth/login.dart';
import '../views/auth/splash.dart';

class AppRoutes {
  static const SPLASH = '/';
  static const HOME = '/home';
  static const LOGIN = '/login';
  static const ADDPASSWORD = '/addpassword';
  static const VIEWALLPASSWORD = '/viewallpassword';
  static const EDITPASSWORD = '/editpassword';

  static Map<String, Widget Function(BuildContext)> getAppRoutes() {
    Map<String, Widget Function(BuildContext)> appRoutes = {
      SPLASH: (BuildContext context) => const Splash(),
      LOGIN: (BuildContext context) => const Login(),
      HOME: (BuildContext context) => const Home(),
      ADDPASSWORD: (BuildContext context) => const AddPassword(),
      VIEWALLPASSWORD: (BuildContext context) => const ViewAllPassword(),
      EDITPASSWORD: (BuildContext context) => const EditPassword(),
    };

    return appRoutes;
  }
}
